from django.db import models
from django.contrib.auth.models import User


## offre de stage
class offreStage(models.Model):

    nom = models.CharField(max_length=100)
    description = models.TextField(null=True)
    datedebut = models.DateField(blank=True, null=True)
    datefin = models.DateField(blank=True, null=True)
    typeoffre = models.CharField(max_length=150, null=True)
    auteur = models.ForeignKey(User, on_delete=models.CASCADE, related_name="offrestage", null=True)

    def __str__(self):
        return self.nom

## Profile d'un utilisateur
class user_profile(models.Model):

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="profile")
    description = models.TextField(null=True)
    isCE = models.BooleanField(default=False)
    site = models.CharField(max_length=200, blank=True, null=True)


## Tables d'archives 

# archive d'une offre de stage
class archiveOffre(models.Model):
    offre = models.OneToOneField(offreStage, on_delete=models.CASCADE, related_name="archiveOffre")

# archive d'un compte 
class archiveCompte(models.Model):
    compte = models.OneToOneField(User, on_delete=models.CASCADE, related_name="archiveCompte")


