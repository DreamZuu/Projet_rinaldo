from django.contrib import admin
from registration.models import archiveCompte, archiveOffre, offreStage, user_profile

# Register your models here.
admin.site.register(offreStage)
admin.site.register(user_profile)
admin.site.register(archiveOffre)
admin.site.register(archiveCompte)