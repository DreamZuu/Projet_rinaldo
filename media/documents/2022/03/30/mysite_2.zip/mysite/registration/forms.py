from django.contrib.auth.models import User
from django.forms import ModelForm
from .models import  offreStage, user_profile

class user_profileForm(ModelForm):
    class Meta:
        model = user_profile
        fields = ['description','isCE','site']

class offreStageForm(ModelForm):
    class Meta:
        model = offreStage
        fields = ['nom','description','auteur']
    
        
    
    
    