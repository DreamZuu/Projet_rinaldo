
from django.contrib.auth import login as auth_login
from django.contrib.auth import authenticate
from django.shortcuts import render, redirect
from django.views.generic.base import TemplateView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.forms import UserCreationForm
from registration.forms import offreStageForm, user_profileForm
from registration.models import offreStage, user_profile


## Login view
def login(request):
    return render(request, "registration/login.html", {})

## Signup view
def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():

            form.save()
            
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            ut = user_profile(user = user)
            user.save()
            ut.save()

            auth_login(request, user)
            return redirect('edit')
    else:
        form = UserCreationForm()
    return render(request, 'registration/signup.html', {'form': form})

def edit(request):
    UP= user_profile.objects.get(user = request.user)
    form = user_profileForm(instance=UP)
    if request.method == 'POST':
        form = user_profileForm(request.POST, instance=UP)
        if form.is_valid():
            form.save()
            return redirect('profile')

    return render(request, 'registration/edit.html', {'form': form})

def addoffre(request):
    current_usr = request.user
    if request.method == 'POST':
        form = offreStageForm(request.POST)
        if form.is_valid():
            n = form.cleaned_data["nom"]
            OS = offreStage(nom=n, auteur=current_usr)
            OS.save()
           
        return redirect('mesoffres')    
    else:
       form = offreStageForm() 
    
    ## Affichage des offres de l'utilisateur
    all_offre= offreStage.objects.filter(auteur = current_usr)
    mynboffre = offreStage.objects.filter(auteur = current_usr).count()
    return render(request, 'registration/addoffre.html', {'alloffre':all_offre, 'mynboffre':mynboffre, 'form':form})


class ProfileView(LoginRequiredMixin, TemplateView):
    template_name="registration/profile.html"



